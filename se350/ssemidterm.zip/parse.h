/*
 * Interface to the parsing function that transforms a string (linear)
 * representation of a tree into an internal, linked data structure.
 *
 * If on return (*syn_error) is true, then the returned pointer is NULL.
 * Otherwise, the returned pointer is to the root of the constructed tree (which
 * may be NULL if the constructed tree is empty).
 *
 * A string tree is defined recursively as:
 *   a) a dot ('.') representing the empty tree (NULL in the data structure).
 *   b) a letter (either case) followed by two string trees.
 *
 * Embedded spaces are NOT permitted.
 * The entire string must be used up in the parser; any extra characters indicate
 * a syntax error.
 */

#ifndef PARSE_H
#define PARSE_H

#include "binary_tree.h"
#include "bool.h"

bintree *parse(char *s, bool *syn_error) ;

#endif
