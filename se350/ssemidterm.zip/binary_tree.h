/*
 * The declaration of the structure representing one node in a binary
 * tree.
 */

#ifndef BINARY_TREE_H
#define BINARY_TREE_H

typedef struct bintree {
	char label ;		/* label - a letter of either case */
	struct bintree *left ;	/* left subtree */
	struct bintree *right ;	/* right subtree */
} bintree ;

#endif
