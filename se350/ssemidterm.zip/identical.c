#include "identical.h"
#define NULL 0

//uses an inorder traversal to compare every element
//of the two trees, starting at root nodes t1,t2
//for to tress to be equivilant, their
bool identical(bintree *t1, bintree *t2){
} 
