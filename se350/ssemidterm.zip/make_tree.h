/*
 * Interface to the function to make a tree from a label and two
 * subtree links. Note that the links may be either NULL (for
 * an empty tree) or may point to bintree nodes for the subtrees.
 */

#ifndef MAKE_TREE_H
#define MAKE_TREE_H

#include "binary_tree.h"

/* 
 * Takes char data and makes a tree.
 */
bintree *make_tree(char label, bintree *left, bintree *right) ;

#endif
