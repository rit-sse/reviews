#include <stdlib.h>

#include "release_tree.h"
//deletes using a postorder traversal
//postorder traveral will delete both
//children before deleting the root
void release_tree(bintree *root){
} 
