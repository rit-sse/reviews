#include "make_tree.h"

//takes a character and two subtress, making them into a root node
//with left and right children. allocates space and assigns
//the paramater children
bintree *make_tree(char label, bintree *left, bintree *right){
}
