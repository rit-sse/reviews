/*
 * Implementation of the parsing function that transforms a string (linear)
 * representation of a tree into an internal, linked data structure.
 *
 * Note that
 * 	a) the global pointer sp allows us to process the string characters left-to-right.
 * 	b) the main function fobs most of the work off to a local recursive function.
 */

#include <stdlib.h>
#include <ctype.h>

#include "parse.h"
#include "make_tree.h"
#include "release_tree.h"

static char *sp ;		/* pointer to the next character in the provided string */

static bintree *parse_r() ;	/* recursive parsing function */

bool validChar(char c);

/*
 * The implementation assumes that the pointer 'sp' is used to access each
 * character in the string 's', and that as each character is used the
 * pointer is advanced to the next character. Thus, when parse_r returns
 * to parse, the character 'sp' points to should be a NUL ('\0').
 */

bintree *parse(char *s, bool *syn_error) {
	bintree *root ;

	sp = s ;		/* start parsing at the beginning of s */
	*syn_error = false ;	/* assume we'll succeed in parsing */

	root = parse_r(syn_error) ;

	if ( ! (*syn_error) && *sp != '\0' ) {	/* chars left over in the string */
		release_tree(root) ;
		root = NULL ;
		*syn_error = true ;
	}

	return root ;
}

/*
 * The heart of the parser.
 *   a) Get the next string character in 'label_ch' using '*sp++' (which
 *      both retrieves the character and advances the pointer).
 *   b) Handle the cases where 'label_ch' is a dot (an empty or NULL tree),
 *      where 'label_ch' is a letter (the label of the tree root), or
 *      anything else (an error - set *syn_error to true and return NULL).
 *   c) for a non-empty tree:
 *         - invoke parse_r for the left subtree.
 *         - if this succeeds (check *syn_error), invoke parse_r for
 *           the right subtree.
 *         - if there are syntax errors, release both the left and right
 *           subtrees and return NULL.
 *         - otherwise make a new tree from the label_ch and the two
 *           subtrees; return the pointer to this new tree.
 * NOTE:
 *    parse_r can only set the *syn_error boolean to true, never to
 *    false.
 */

static bintree *parse_r(bool *syn_error) {
	bintree *root;
	char label_ch ;
	bintree *left = NULL ;
	bintree *right = NULL ;
	/* FILL THIS IN */
}
