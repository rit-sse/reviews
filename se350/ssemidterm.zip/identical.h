/*
 * Recursive function to determine whether or not two trees are
 * identical.
 *
 * Two trees are identical iff
 *	1) both trees are empty (NULL) or
 *	2) neither tree is empty and the root node labels are the same and
 *		a) the left subtrees are identical and
 *		b) the right subtrees are identical.
 */

#ifndef IDENTICAL_H
#define IDENTICAL_H

#include "bool.h"
#include "binary_tree.h"

bool identical(bintree *t1, bintree *t2) ;

#endif
