/*
 * Interface to the function to release all the storage associated
 * with a tree given a pointer to the root. If the root is empty
 * (NULL) simply return. Otherwise, release the left and right
 * subtrees, then release storage for the root node.
 */

#ifndef RELEASE_TREE_H
#define RELEASE_TREE_H

#include "binary_tree.h"

void release_tree(bintree *root) ;

#endif
