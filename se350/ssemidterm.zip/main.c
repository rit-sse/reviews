/*
 * Main driver program:
 * 	a) Read two lines of text from standard input.
 * 	b) (Attempt to) parse the lines as trees.
 * 	c) If syntax errors, report same an exit.
 * 	d) Otherwise, determine whether the trees are
 * 		i)   identical
 * 		ii)  similar
 * 		iii) uncomparable
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "bool.h"

#include "binary_tree.h"

#include "parse.h"
#include "release_tree.h"

#include "identical.h"
#include "similar.h"

#define MAXLINE	(99)	/* maximum text line size */

static void getLine(char *buf, int size) {
	int lc ;

	fgets(buf, size, stdin) ;
	lc = strlen(buf) - 1 ;
	if ( lc >= 0 && buf[lc] == '\n' ) {
		buf[lc] = '\0' ;
	}

	return ;
}

int main() {
	char line[MAXLINE+1] ;
	bool error ;
	bintree *t1 ;
	bintree *t2 ;


	/*
	 * Get and parse the first tree string.
	 */

	getLine(line, MAXLINE) ;
	t1 = parse(line, &error) ;

	if ( error ) {
		printf("*** Syntax error in first line\n") ;
		return 1 ;
	}

	/*
	 * Get and parse the second tree string.
	 */

	getLine(line, MAXLINE) ;
	t2 = parse(line, &error) ;

	if ( error ) {
		printf("*** Syntax error in second line\n") ;
		release_tree(t1) ;
		return 1 ;
	}

	if ( identical(t1, t2) ) {
		printf("The trees are identical.\n") ;
	} else if ( similar(t1, t2) ) {
		printf("The trees are similar.\n") ;
	} else {
		printf("The trees are uncomparable.\n") ;
	}

	return 0 ;
}

