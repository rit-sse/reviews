#include <stdlib.h>
#include "similar.h"

//determines if 2 trees are similar
//similarity is that given a root node, 
//t1l == t2l and t1r == t2l OR
//t1l == t2r and t1r == t2r
//and their children are similar
//
//uses an inorder traversal variant that swaps
//the left and right nodes where appropriate
bool similar(bintree *t1, bintree *t2){
}
