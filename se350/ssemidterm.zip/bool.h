/*
 * Convenience declaration of a boolean type.
 */

#ifndef BOOL_H
#define BOOL_H

typedef enum {false, true} bool ;

#endif
