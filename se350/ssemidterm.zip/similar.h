/*
 * Recursive function to determine whether or not two trees are
 * similar.
 *
 * Two trees, t1 and t2, are similar iff
 *	1) both t1 and t2 are empty (NULL) or
 *	2) neither t1 nor t2 is empty and their root labels are equal and
 *	   either
 *		a) the left subtree of t1 is similar to the left subtree of t2 and
 *		b) the right subtree of t1 is similar to the right subtree of t2
 *	   or
 *	   	c) the left subtree of t1 is similar to the right subtree of t2 and
 *	   	d) the right subtree of t1 is similar to the left subtree of t2.
 */

#ifndef IDENTICAL_H
#define IDENTICAL_H

#include "bool.h"
#include "binary_tree.h"

bool similar(bintree *t1, bintree *t2) ;

#endif
